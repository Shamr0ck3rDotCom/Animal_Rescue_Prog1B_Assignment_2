package com.mycompany.wildliferescuesystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */

import com.mycompany.wildliferescuesystem.RescueCase;
import java.util.ArrayList;

public class RescueManager {
    private ArrayList<RescueCase>rescueCases;
    
    public RescueManager(){
        rescueCases=new ArrayList<>();
    }
    
    public void addRescueCase(RescueCase newCase){
    for (RescueCase existingCase : rescueCases) {
        if (existingCase.getRescueCaseId().equals(newCase.getRescueCaseId())) {
            System.out.println("Error: A rescue case with this ID already exists.");
            return;
        }
    }
    rescueCases.add(newCase);
}
    
    public RescueCase searchByCaseId(String id){
    for (RescueCase existingCase : rescueCases) {
        if (existingCase.getRescueCaseId().equals(id)) {
            return existingCase;
        }
    }
    return null;
}
    public void updateStatus(String id, String newStatus){
    RescueCase found = searchByCaseId(id);
    
    if (found == null) {
        System.out.println("Error: no rescue case found with that ID.");
        return;
    }
    
    found.setCurrentRescueStatus(newStatus);
}
    
    public ArrayList<RescueCase> getAllRescueCases(){
    return rescueCases;
}

public int getTotalCaseCount(){
    return rescueCases.size();
}

    public double getTotalRescueCost(){
    double total = 0;
    for (RescueCase existingCase : rescueCases) {
        total = total + existingCase.calculateTotalRescueCost();
    }
    return total;
}
    
}
