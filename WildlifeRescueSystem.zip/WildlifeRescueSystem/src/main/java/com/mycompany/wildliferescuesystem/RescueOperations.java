package com.mycompany.wildliferescuesystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */
public interface RescueOperations {
    void startRescueOperation();
    void completeRescueOperation();
    String generateRescueSummary();
    
}
