package com.mycompany.wildliferescuesystem;


import com.mycompany.wildliferescuesystem.RescueCase;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */
public class OrphanedAnimalRescue extends RescueCase {
    private int estimatedAge;
    private double feedingCost;
    private boolean fosterCareRequired;
    
    public OrphanedAnimalRescue(String rescueCaseId, String species, String animalName, String rescueLocation, String assignedRanger, int numberOfRescueDays, double dailyCareCost, int estimatedAge, double feedingCost, boolean fosterCareRequired){
        
        super(rescueCaseId, species, animalName, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.estimatedAge=estimatedAge;
        this.feedingCost=feedingCost;
        this.fosterCareRequired=fosterCareRequired;
    }
    @Override
    public String determineRescuePriority(){
        if (estimatedAge<=2){
            return "High";
        }else if (fosterCareRequired){
            return "Medium";
        }else {
            return "Low";
        }
    }
    @Override
    public double calculateTotalRescueCost(){
        double total=getDailyCareCost()*getNumberOfRescueDays();
        total=total+feedingCost;
        if(fosterCareRequired){
            total=total+2500;
        }
        return total;
    }
    @Override
    public void displaySpecificInfo(){
        System.out.println("Estimated Age: " + estimatedAge );
        System.out.println("Feeding Cost: " + feedingCost);
        System.out.println("Is Fostter Care Required: " + fosterCareRequired );
    }
    
}
