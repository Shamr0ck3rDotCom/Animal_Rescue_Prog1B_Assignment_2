package com.mycompany.wildliferescuesystem;


import com.mycompany.wildliferescuesystem.RescueCase;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */
public class InjuredAnimalRescue extends RescueCase {
    
    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;
    
    public InjuredAnimalRescue(String rescueCaseId, String species, String animalName,String rescueLocation, String assignedRanger, int numberOfRescueDays, double dailyCareCost, String injuryDescription, double veterinaryTreatmentCost, boolean surgeryRequired){
        
        super(rescueCaseId, species, animalName, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.injuryDescription=injuryDescription;
        this.veterinaryTreatmentCost=veterinaryTreatmentCost;
        this.surgeryRequired=surgeryRequired;
        
    }
    @Override
    public double calculateTotalRescueCost(){
        double total=getDailyCareCost()*getNumberOfRescueDays();
        total=total+veterinaryTreatmentCost;
        if (surgeryRequired){
            total=total + 5000;
        }
        return total;
    }
    @Override
    public String determineRescuePriority(){
        if (surgeryRequired){
            return "Critical";
            
        }else if (veterinaryTreatmentCost>5000){
            return "High";
        }else {
            return "Medium";
        }
    }
    @Override
    public void displaySpecificInfo(){
        System.out.println("Injury Description: " + injuryDescription);
        System.out.println("Surgery Required? " + surgeryRequired);
        System.out.println("Veterinary Treatment Cost: " + veterinaryTreatmentCost);
    }
    
}
