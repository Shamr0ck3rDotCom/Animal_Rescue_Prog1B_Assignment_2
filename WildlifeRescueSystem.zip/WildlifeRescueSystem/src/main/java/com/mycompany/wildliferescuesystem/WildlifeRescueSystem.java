package com.mycompany.wildliferescuesystem;

import java.util.Scanner;

public class WildlifeRescueSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RescueManager manager = new RescueManager();
        boolean running = true;

        while (running) {
            System.out.println("\n========================================");
            System.out.println("   WILDLIFE RESCUE OPERATIONS SYSTEM");
            System.out.println("========================================");
            System.out.println("1. Create Rescue Case");
            System.out.println("2. Search Rescue Case");
            System.out.println("3. Update Rescue Status");
            System.out.println("4. Display All Rescue Cases");
            System.out.println("5. Rescue Report");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    createRescueCase(scanner, manager);
                    break;
                case "2":
                    searchRescueCase(scanner, manager);
                    break;
                case "3":
                    updateRescueStatus(scanner, manager);
                    break;
                case "4":
                    displayAllRescueCases(manager);
                    break;
                case "5":
                    rescueReport(manager);
                    break;
                case "6":
                    running = false;
                    System.out.println("Exiting Wildlife Rescue Operations System. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
        scanner.close();
    }

    // ---------- Validation helper methods ----------

    private static String readNonBlank(Scanner scanner, String prompt) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("This field cannot be blank. Please try again.");
        }
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Value must be greater than zero. Please try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Value must be greater than zero. Please try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static boolean readYesNo(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("y")) {
                return true;
            } else if (input.equalsIgnoreCase("no") || input.equalsIgnoreCase("n")) {
                return false;
            }
            System.out.println("Please enter yes or no.");
        }
    }

    // ---------- Menu option 1: Create Rescue Case ----------

    private static void createRescueCase(Scanner scanner, RescueManager manager) {
        System.out.println("\n-- Create Rescue Case --");

        String id = readNonBlank(scanner, "Rescue Case ID: ");
        if (manager.searchByCaseId(id) != null) {
            System.out.println("Error: A rescue case with ID '" + id + "' already exists.");
            return;
        }

        String species = readNonBlank(scanner, "Species: ");
        String animalName = readNonBlank(scanner, "Animal Name: ");
        String location = readNonBlank(scanner, "Rescue Location: ");
        String ranger = readNonBlank(scanner, "Assigned Ranger: ");
        int days = readPositiveInt(scanner, "Number of Rescue Days: ");
        double dailyCost = readPositiveDouble(scanner, "Daily Care Cost: R");

        System.out.println("Select Rescue Case Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        String typeChoice = readNonBlank(scanner, "Enter choice (1-3): ");

        RescueCase newCase = null;

        if (typeChoice.equals("1")) {
            String injury = readNonBlank(scanner, "Injury Description: ");
            double vetCost = readPositiveDouble(scanner, "Veterinary Treatment Cost: R");
            boolean surgery = readYesNo(scanner, "Surgery Required? (yes/no): ");
            newCase = new InjuredAnimalRescue(id, species, animalName, location, ranger,
                    days, dailyCost, injury, vetCost, surgery);

        } else if (typeChoice.equals("2")) {
            int age = readPositiveInt(scanner, "Estimated Age (Months): ");
            double feedingCost = readPositiveDouble(scanner, "Feeding Cost: R");
            boolean foster = readYesNo(scanner, "Foster Care Required? (yes/no): ");
            newCase = new OrphanedAnimalRescue(id, species, animalName, location, ranger,
                    days, dailyCost, age, feedingCost, foster);

        } else if (typeChoice.equals("3")) {
            String classification = readNonBlank(scanner, "Conservation Classification: ");
            double securityCost = readPositiveDouble(scanner, "Security Cost: R");
            boolean specialist = readYesNo(scanner, "Specialist Team Required? (yes/no): ");
            newCase = new EndangeredSpeciesRescue(id, species, animalName, location, ranger,
                    days, dailyCost, classification, securityCost, specialist);

        } else {
            System.out.println("Invalid rescue case type selected. Case not created.");
            return;
        }

        manager.addRescueCase(newCase);
        System.out.println("\nRescue case created successfully.");
        System.out.println(newCase.generateRescueSummary());
    }

    // ---------- Menu option 2: Search Rescue Case ----------

    private static void searchRescueCase(Scanner scanner, RescueManager manager) {
        System.out.println("\n-- Search Rescue Case --");
        String id = readNonBlank(scanner, "Enter Rescue Case ID: ");
        RescueCase found = manager.searchByCaseId(id);
        if (found == null) {
            System.out.println("No rescue case found with ID '" + id + "'.");
        } else {
            displayFullCase(found);
        }
    }

    // ---------- Menu option 3: Update Rescue Status ----------

    private static void updateRescueStatus(Scanner scanner, RescueManager manager) {
        System.out.println("\n-- Update Rescue Status --");
        String id = readNonBlank(scanner, "Enter Rescue Case ID: ");
        RescueCase found = manager.searchByCaseId(id);
        if (found == null) {
            System.out.println("No rescue case found with ID '" + id + "'.");
            return;
        }
        System.out.println("Current Status: " + found.getCurrentRescueStatus());
        String newStatus = readNonBlank(scanner, "Enter New Status (e.g. Rescue in Progress, Under Observation, Completed): ");
        manager.updateStatus(id, newStatus);
        System.out.println("Status updated successfully.");
    }

    // ---------- Menu option 4: Display All Rescue Cases ----------

    private static void displayAllRescueCases(RescueManager manager) {
        System.out.println("\n-- All Rescue Cases --");
        if (manager.getTotalCaseCount() == 0) {
            System.out.println("No rescue cases currently stored.");
            return;
        }
        for (RescueCase rc : manager.getAllRescueCases()) {
            displayFullCase(rc);
            System.out.println("----------------------------------------");
        }
    }

    // ---------- Menu option 5: Rescue Report ----------

    private static void rescueReport(RescueManager manager) {
        System.out.println("\n========================================");
        System.out.println("           WILDLIFE RESCUE REPORT");
        System.out.println("========================================");

        if (manager.getTotalCaseCount() == 0) {
            System.out.println("No rescue cases currently stored.");
        } else {
            for (RescueCase rc : manager.getAllRescueCases()) {
                System.out.println("Case ID   : " + rc.getRescueCaseId());
                System.out.println("Type      : " + rc.getClass().getSimpleName());
                System.out.println("Species   : " + rc.getSpecies());
                System.out.println("Location  : " + rc.getRescueLocation());
                System.out.println("Ranger    : " + rc.getAssignedRanger());
                System.out.println("Priority  : " + rc.determineRescuePriority());
                System.out.println("Status    : " + rc.getCurrentRescueStatus());
                System.out.printf("Total Cost: R%.2f%n", rc.calculateTotalRescueCost());
                System.out.println("----------------------------------------");
            }
        }

        System.out.println();
        System.out.println("Total Rescue Cases: " + manager.getTotalCaseCount());
        System.out.printf("Total Rescue Cost : R%.2f%n", manager.getTotalRescueCost());
    }

    // ---------- Shared display helper ----------

    private static void displayFullCase(RescueCase rc) {
        System.out.println("Rescue Case ID  : " + rc.getRescueCaseId());
        System.out.println("Rescue Type     : " + rc.getClass().getSimpleName());
        System.out.println("Animal Name     : " + rc.getAnimalName());
        System.out.println("Species         : " + rc.getSpecies());
        System.out.println("Rescue Location : " + rc.getRescueLocation());
        System.out.println("Assigned Ranger : " + rc.getAssignedRanger());
        System.out.println("Rescue Days     : " + rc.getNumberOfRescueDays());
        System.out.printf("Daily Care Cost : R%.2f%n", rc.getDailyCareCost());
        rc.displaySpecificInfo();
        System.out.println("Rescue Priority : " + rc.determineRescuePriority());
        System.out.println("Current Status  : " + rc.getCurrentRescueStatus());
        System.out.printf("Total Cost      : R%.2f%n", rc.calculateTotalRescueCost());
    }
}
