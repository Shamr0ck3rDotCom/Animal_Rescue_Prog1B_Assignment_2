package com.mycompany.wildliferescuesystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */
public abstract class RescueCase implements RescueOperations{
    
    private String rescueCaseId;
    private String species;
    private String animalName;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;
    
    public RescueCase(String rescueCaseId, String species, String animalName, String rescueLocation,String assignedRanger,int numberOfRescueDays, double dailyCareCost){
        this.rescueCaseId=rescueCaseId;
        this.species=species;
        this.animalName=animalName;
        this.rescueLocation=rescueLocation;
        this.assignedRanger=assignedRanger;
        this.numberOfRescueDays=numberOfRescueDays;
        this.dailyCareCost=dailyCareCost;
        this.currentRescueStatus="Pending";
        
          
        
   //Getters
    }
    public String getRescueCaseId(){
            return rescueCaseId;
        }
    public String getSpecies(){
        return species;
    }
    public String getAnimalName(){
        return animalName;
    }
    public String getRescueLocation(){
        return rescueLocation;
    }
    public String getAssignedRanger(){
        return assignedRanger;
    }
    public int getNumberOfRescueDays(){
        return numberOfRescueDays;
    }
    public double getDailyCareCost(){
        return dailyCareCost;
    }
    public String getCurrentRescueStatus(){
        return currentRescueStatus;
    }
    
    public abstract double calculateTotalRescueCost();
    public abstract String determineRescuePriority();
    public abstract void displaySpecificInfo();
    
    @Override
    public void startRescueOperation(){
        currentRescueStatus="Rescue in Progress";
    }
    @Override
    public void completeRescueOperation(){
        currentRescueStatus="Completed";
    }
    @Override
    public String generateRescueSummary(){
        String summary="Rescue Case ID: " + rescueCaseId + "\n";
        summary=summary + "Species: " + species + "\n";
        summary=summary + "Assigned Ranger: " + assignedRanger + "\n";
        summary=summary + "Rescue Priority: " + determineRescuePriority() + "\n";
        summary=summary + "Current Status: " + currentRescueStatus + "\n";
        summary=summary + "Total Rescue Cost: R" + calculateTotalRescueCost();
        return summary;
    }
     //Setters
    
    public void setAnimalName(String animalName){
        this.animalName=animalName;
    }
    public void setRescueLocation(String rescueLocation){
        this.rescueLocation=rescueLocation;
    }
    public void setAssignedRanger(String assignedRanger){
        this.assignedRanger=assignedRanger;
    }
    public void setNumberOfRescueDays(int numberOfRescueDays){
        this.numberOfRescueDays=numberOfRescueDays;
    }
    public void setDailyCareCost(double dailyCareCost){
        this.dailyCareCost=dailyCareCost;
    }
    public void setCurrentRescueStatus(String currentRescueStatus){
        this.currentRescueStatus=currentRescueStatus;
    }
    
    
}
