package com.mycompany.wildliferescuesystem;


import com.mycompany.wildliferescuesystem.RescueCase;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHAMIEL_T
 */
public class EndangeredSpeciesRescue extends RescueCase {
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;
    
    public EndangeredSpeciesRescue(String rescueCaseId, String species, String animalName, String rescueLocation, String assignedRanger, int numberOfRescueDays, double dailyCareCost, String conservationClassification, double securityCost, boolean specialistTeamRequired){
        super(rescueCaseId, species, animalName, rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        this.conservationClassification=conservationClassification;
        this.securityCost=securityCost;
        this.specialistTeamRequired=specialistTeamRequired;
    }
    @Override
    public double calculateTotalRescueCost(){
        double total=getDailyCareCost()*getNumberOfRescueDays();
        total=total+securityCost;
        if(specialistTeamRequired){
            total=total+8000;
        }
        return total;
    }
    @Override
    public String determineRescuePriority(){
        if(specialistTeamRequired){
            return "Critical";
        }else {
           return "High"; 
        }
            
    }
    @Override
    public void displaySpecificInfo(){
        System.out.println("Conservation Classification: " + conservationClassification);
        System.out.println("Security Cost: " + securityCost);
        System.out.println("Specialist Team Required: " + specialistTeamRequired);
        
    }
}


