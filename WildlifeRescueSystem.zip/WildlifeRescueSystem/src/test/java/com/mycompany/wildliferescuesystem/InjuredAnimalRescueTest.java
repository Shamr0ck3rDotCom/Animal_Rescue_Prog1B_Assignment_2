package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class InjuredAnimalRescueTest {

    private InjuredAnimalRescue instance;

    @BeforeEach
    public void setUp() {
        instance = new InjuredAnimalRescue("WR101", "African Elephant", "Tembo",
                "Kruger Park", "John Smith", 5, 300.0,
                "Broken leg", 2000.0, true);
    }

    @Test
    public void testCalculateTotalRescueCost() {
        double expResult = 8500.0; // (300*5) + 2000 + 5000 surgery
        double result = instance.calculateTotalRescueCost();
        assertEquals(expResult, result, 0.001);
    }

    @Test
    public void testDetermineRescuePriority() {
        String expResult = "Critical"; // surgeryRequired is true
        String result = instance.determineRescuePriority();
        assertEquals(expResult, result);
    }

    @Test
    public void testDisplaySpecificInfo() {
        // This method only prints to console and returns nothing,
        // so there's nothing to assert - just confirm it runs without crashing
        instance.displaySpecificInfo();
    }
}