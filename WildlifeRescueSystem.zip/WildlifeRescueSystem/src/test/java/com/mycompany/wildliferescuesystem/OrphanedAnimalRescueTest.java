package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrphanedAnimalRescueTest {

    private OrphanedAnimalRescue instance;

    @BeforeEach
    public void setUp() {
        instance = new OrphanedAnimalRescue("WR201", "White Rhino", "Baby Rhino",
                "Hluhluwe", "Peter Ranger", 4, 150.0,
                1, 800.0, true);
    }

    @Test
    public void testCalculateTotalRescueCost() {
        double expResult = 3900.0; // (150*4) + 800 + 2500 foster care
        double result = instance.calculateTotalRescueCost();
        assertEquals(expResult, result, 0.001);
    }

    @Test
    public void testDetermineRescuePriority() {
        String expResult = "High"; // estimatedAge is 1, which is <= 2
        String result = instance.determineRescuePriority();
        assertEquals(expResult, result);
    }

    @Test
    public void testDisplaySpecificInfo() {
        instance.displaySpecificInfo();
    }
}