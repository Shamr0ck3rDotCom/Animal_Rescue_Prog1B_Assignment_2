package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RescueManagerTest {

    private RescueManager manager;

    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
        manager.addRescueCase(new InjuredAnimalRescue("WR101", "African Elephant", "Tembo",
                "Kruger Park", "John Smith", 5, 300.0,
                "Broken leg", 2000.0, true));
    }

    @Test
    public void testSearchFindsExistingCase() {
        RescueCase found = manager.searchByCaseId("WR101");
        assertNotNull(found);
        assertEquals("WR101", found.getRescueCaseId());
    }

    @Test
    public void testSearchReturnsNullForUnknownId() {
        RescueCase found = manager.searchByCaseId("UNKNOWN");
        assertNull(found);
    }

    @Test
    public void testDuplicateRescueCaseIdIsRejected() {
        manager.addRescueCase(new OrphanedAnimalRescue("WR101", "White Rhino", "Baby Rhino",
                "Hluhluwe", "Peter Ranger", 4, 150.0,
                1, 800.0, true));
        // The duplicate should NOT have been added - count should still be 1
        assertEquals(1, manager.getTotalCaseCount());
    }

    @Test
    public void testUpdateStatusOnExistingCase() {
        manager.updateStatus("WR101", "Under Observation");
        RescueCase found = manager.searchByCaseId("WR101");
        assertEquals("Under Observation", found.getCurrentRescueStatus());
    }

    @Test
    public void testUpdateStatusOnUnknownCaseDoesNothing() {
        manager.updateStatus("UNKNOWN", "Under Observation");
        // Should not crash, and the real case's status should be untouched
        RescueCase found = manager.searchByCaseId("WR101");
        assertEquals("Pending", found.getCurrentRescueStatus());
    }
}