package com.mycompany.wildliferescuesystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EndangeredSpeciesRescueTest {

    private EndangeredSpeciesRescue instance;

    @BeforeEach
    public void setUp() {
        instance = new EndangeredSpeciesRescue("WR301", "Black Rhino", "N/A",
                "Addo National Park", "Lindiwe Ranger", 6, 500.0,
                "Critically Endangered", 4000.0, true);
    }

    @Test
    public void testCalculateTotalRescueCost() {
        double expResult = 15000.0; // (500*6) + 4000 + 8000 specialist team
        double result = instance.calculateTotalRescueCost();
        assertEquals(expResult, result, 0.001);
    }

    @Test
    public void testDetermineRescuePriority() {
        String expResult = "Critical"; // specialistTeamRequired is true
        String result = instance.determineRescuePriority();
        assertEquals(expResult, result);
    }

    @Test
    public void testDisplaySpecificInfo() {
        instance.displaySpecificInfo();
    }
}